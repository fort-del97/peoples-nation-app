import React from 'react';

function App() {
  return <div>Welcome to The People's Nation</div>;
}

export default App;